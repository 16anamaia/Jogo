package MontyHall;
import java.util.Scanner;
import java.util.Random;

public class Jogo {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Random random = new Random();

        int portaPremiada = random.nextInt(3) + 1;
        int portaVazia = 0;
        int portaEscolhida = 0;

        System.out.println("Bem-vindo ao Jogo da Porta dos Desesperados!");
        System.out.println("Atrás de uma das três portas há um prêmio, e atrás das outras duas portas estão vazias.");
        System.out.println("Escolha uma porta (1, 2 ou 3): ");

        portaEscolhida = scanner.nextInt();


        do {
            portaVazia = random.nextInt(3) + 1;
        } while (portaVazia == portaEscolhida || portaVazia == portaPremiada);

        System.out.println("A porta " + portaVazia + " está vazia.");
        System.out.println("Você deseja trocar de porta? (S para sim, N para não): ");

        char escolha = scanner.next().charAt(0);

        if (escolha == 'S' || escolha == 's') {
            
            do {
                portaEscolhida = random.nextInt(3) + 1;
            } while (portaEscolhida == portaEscolhida || portaEscolhida == portaVazia);
        }

        if (portaEscolhida == portaPremiada) {
            System.out.println("Parabéns! Você ganhou o prêmio!");
        } else {
            System.out.println("Você perdeu. A porta premiada era a porta " + portaPremiada + ".");
        }

        scanner.close();
    }
}
